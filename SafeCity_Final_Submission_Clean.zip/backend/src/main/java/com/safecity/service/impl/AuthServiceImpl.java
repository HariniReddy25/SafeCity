package com.safecity.service.impl;

import com.safecity.dto.AuthResponseDTO;
import com.safecity.dto.LoginRequestDTO;
import com.safecity.dto.RegisterRequestDTO;
import com.safecity.dto.UserDTO;
import com.safecity.entity.Role;
import com.safecity.entity.User;
import com.safecity.repository.UserRepository;
import com.safecity.security.jwt.JwtTokenProvider;
import com.safecity.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenProvider tokenProvider;

    @Override
    public AuthResponseDTO register(RegisterRequestDTO request) {
        if (!request.getPassword().equals(request.getConfirmPassword())) {
            throw new IllegalArgumentException("Password and confirm password do not match");
        }

        if (userRepository.existsByEmail(request.getEmail().toLowerCase().trim())) {
            throw new IllegalArgumentException("Email is already registered: " + request.getEmail());
        }

        // Security Enforcement: Public registration ALWAYS assigns CITIZEN role
        Role assignedRole = Role.CITIZEN;

        User user = new User(
                request.getFullName().trim(),
                request.getEmail().toLowerCase().trim(),
                request.getPhoneNumber().trim(),
                passwordEncoder.encode(request.getPassword()),
                assignedRole
        );

        User savedUser = userRepository.save(user);

        // Generate JWT Token
        String token = tokenProvider.generateTokenForUser(savedUser.getEmail(), savedUser.getRole().name());

        return new AuthResponseDTO(token, UserDTO.fromEntity(savedUser));
    }

    @Override
    public AuthResponseDTO login(LoginRequestDTO request) {
        String email = request.getEmail().toLowerCase().trim();

        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(email, request.getPassword())
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);

            User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> new BadCredentialsException("User not found"));

            String token = tokenProvider.generateToken(authentication);

            return new AuthResponseDTO(token, UserDTO.fromEntity(user));
        } catch (BadCredentialsException ex) {
            throw new BadCredentialsException("Invalid email or password");
        }
    }
}
